package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    String[] nameArray = {"Masjid Miftahul Ihsan","Masjid Jami","Masjid Al Jihad","Masjid Hasanuddin Madjedi","Masjid Imam Syafii","Masjid Utsman Bin Affan","Masjid An Noor","Masjid Raya Sabilal Muhtadin","Masjid Sultan Suriansyah","Masjid At Taqwa" };

    String[] infoArray = {
            "Ini adalah Masjid Miftahul Ihsan",
            "Ini adalah Masjid Jami",
            "Ini adalah Masjid Al Jihad",
            "Ini adalah Masjid Hasanuddin Madjedi",
            "Ini adalah Masjid Imam Syafii",
            "Ini adalah Masjid Utsman Bin affan",
            "Ini adalah Masjid An-Noor",
            "Ini adalah Masjid Raya sabilal Muhtadin",
            "Ini adalah Masjid Sultan Suriansyah",
            "Ini adalah Masjid At-Taqwa."
    };

    Integer[] imageArray = {R.drawable.ihsan,
            R.drawable.jami,
            R.drawable.jihad,
            R.drawable.mhm,
            R.drawable.mis,
            R.drawable.muba,
            R.drawable.noor,
            R.drawable.sabilal,
            R.drawable.sultan_suriansyah,
            R.drawable.taqwa};

    ListView listView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomListAdapter masjid_bjm = new CustomListAdapter(this, nameArray, infoArray, imageArray);
        listView = (ListView) findViewById(R.id.listviewID);
        listView.setAdapter(masjid_bjm);
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (position == 0) {
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), ihsan.class);
                            startActivityForResult(myIntent, 0);

                        }else if(position==1){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), jami.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==2){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), jihad.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==3){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), mhm.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==4){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), mis.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==5){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), muba.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==6){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), noor.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==7){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), sabilal.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==8){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), sultan_suriansyah.class);
                            startActivityForResult(myIntent, 0);
                        }else if(position==9){
                            //code specific to first list item
                            Intent myIntent = new Intent(view.getContext(), taqwa.class);
                            startActivityForResult(myIntent, 0);
                        }
                    }


                });

    }
    public boolean onCreateOptionsMenu(Menu menu)
    {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.about_button,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.about_klik:
                Intent aboutme= new Intent(MainActivity.this, about.class);
                startActivity(aboutme);
                return true;
        }
        return false;
    }
}
